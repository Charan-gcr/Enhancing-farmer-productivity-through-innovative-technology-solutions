import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

export type AnalyzeRequest = { crop: string; symptom: string; location: string };
export type AnalyzeResponse = {
  soilSummary: string;
  yieldSummary: string;
  diseaseStatus: string;
  treatmentSummary: string;
};

@Injectable({ providedIn: 'root' })
export class CropService {
  constructor(private http: HttpClient) {}

  analyze(req: AnalyzeRequest) {
    return this.http.post<AnalyzeResponse>(`${environment.cropBaseUrl}/crop/analyze`, req);
  }
}

