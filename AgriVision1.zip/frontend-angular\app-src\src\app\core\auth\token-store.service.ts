import { Injectable } from '@angular/core';

const TOKEN_KEY = 'agri_access_token';
const ROLE_KEY = 'agri_roles';

@Injectable({ providedIn: 'root' })
export class TokenStoreService {
  set(accessToken: string, roles: string[] = []) {
    localStorage.setItem(TOKEN_KEY, accessToken);
    localStorage.setItem(ROLE_KEY, JSON.stringify(roles));
  }

  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  getRoles(): string[] {
    const raw = localStorage.getItem(ROLE_KEY);
    if (!raw) return [];
    try {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  clear() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(ROLE_KEY);
  }
}

