$ErrorActionPreference = "Stop"

$root = Resolve-Path "$PSScriptRoot\..\.."
$frontRoot = Join-Path $root "frontend-angular"
$target = Join-Path $frontRoot "agrivision-ui"
$src = Join-Path $frontRoot "app-src"

if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw "Node.js not found. Install Node.js first." }
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { throw "npm not found. Install Node.js (includes npm)." }

if (Test-Path $target) {
  Write-Host "Target already exists: $target" -ForegroundColor Yellow
  Write-Host "Delete it if you want a fresh scaffold." -ForegroundColor Yellow
  exit 1
}

Write-Host "Scaffolding Angular app..." -ForegroundColor Cyan
Push-Location $frontRoot

# Use npx to avoid requiring global @angular/cli
npx -y @angular/cli@latest new agrivision-ui --routing --style=css --skip-git --package-manager=npm

Write-Host "Installing extra deps..." -ForegroundColor Cyan
Push-Location $target
npm install
Pop-Location

Write-Host "Copying prepared source code..." -ForegroundColor Cyan
Copy-Item -Path (Join-Path $src "*") -Destination $target -Recurse -Force

Write-Host "Done. Start with:" -ForegroundColor Green
Write-Host "  cd frontend-angular\agrivision-ui" -ForegroundColor Green
Write-Host "  npm start" -ForegroundColor Green

Pop-Location

