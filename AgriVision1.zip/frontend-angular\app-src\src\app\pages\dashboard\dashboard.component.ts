import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CropService, AnalyzeResponse } from '../../core/crop/crop.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent {
  loading = false;
  error = '';
  result: AnalyzeResponse | null = null;

  form = this.fb.group({
    location: ['', [Validators.required, Validators.minLength(2)]],
    crop: ['', [Validators.required]],
    symptom: ['none', [Validators.required]],
  });

  crops = ['Rice', 'Wheat', 'Cotton', 'Maize', 'Sugarcane', 'Groundnut', 'Tomato', 'Potato', 'Tea'];
  symptoms = [
    { value: 'none', label: 'Healthy (Soil & Yield only)' },
    { value: 'spots', label: 'Brown/Black Spots' },
    { value: 'yellowing', label: 'Yellowing Leaves' },
    { value: 'wilting', label: 'Drooping/Wilting' },
    { value: 'holes', label: 'Insect Bites/Holes' },
  ];

  constructor(private fb: FormBuilder, private cropService: CropService) {}

  analyze() {
    this.error = '';
    this.result = null;
    if (this.form.invalid) {
      this.error = 'Select location, crop, and symptom before analyzing.';
      return;
    }

    this.loading = true;
    this.cropService.analyze(this.form.getRawValue()).subscribe({
      next: (res) => {
        this.loading = false;
        this.result = res;
      },
      error: (e) => {
        this.loading = false;
        this.error = e?.error?.message || e?.error?.detail || 'Analyze failed.';
      },
    });
  }
}

