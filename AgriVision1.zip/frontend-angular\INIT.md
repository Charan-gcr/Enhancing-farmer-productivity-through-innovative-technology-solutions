## Angular frontend (setup on your other laptop)

This folder contains the full Angular app source code, but it is not generated with Angular CLI on this machine (Node/npm not installed here).

### On the other laptop (with Node installed)

1. Open a terminal in the repo root.
2. Run:

```powershell
PowerShell -ExecutionPolicy Bypass -File .\frontend-angular\scripts\init-angular.ps1
```

This will:
- create `frontend-angular/agrivision-ui/` using Angular CLI
- copy the prepared app code from `frontend-angular/app-src/`
- install dependencies

3. Start the UI:

```powershell
cd .\frontend-angular\agrivision-ui
npm start
```

### Backend URLs

The UI expects:
- Auth service: `http://localhost:8081`
- Crop service: `http://localhost:8082`
- Admin service: `http://localhost:8083`

