import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { TokenStoreService } from './token-store.service';
import { decodeJwtPayload } from './jwt.util';

export type RegisterRequest = {
  fullName: string;
  email?: string;
  phone?: string;
  password: string;
};

export type LoginRequest = {
  username: string;
  password: string;
};

@Injectable({ providedIn: 'root' })
export class AuthService {
  constructor(private http: HttpClient, private tokenStore: TokenStoreService) {}

  register(req: RegisterRequest) {
    return this.http.post(`${environment.authBaseUrl}/auth/register`, req);
  }

  login(req: LoginRequest) {
    return this.http
      .post<{ accessToken: string; tokenType: string }>(`${environment.authBaseUrl}/auth/login`, req)
      .pipe(
        map((res) => {
          const payload = decodeJwtPayload(res.accessToken);
          const roles = Array.isArray(payload?.roles) ? payload.roles : [];
          this.tokenStore.set(res.accessToken, roles);
          return res;
        })
      );
  }

  logout() {
    this.tokenStore.clear();
  }

  isLoggedIn(): boolean {
    return !!this.tokenStore.getToken();
  }

  isAdmin(): boolean {
    return this.tokenStore.getRoles().includes('ADMIN');
  }
}

