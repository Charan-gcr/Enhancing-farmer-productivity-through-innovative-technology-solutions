import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/auth/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent {
  loading = false;
  error = '';

  form = this.fb.group({
    fullName: ['', [Validators.required, Validators.minLength(2)]],
    email: [''],
    phone: [''],
    password: ['', [Validators.required, Validators.minLength(8)]],
  });

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {}

  submit() {
    this.error = '';
    if (this.form.invalid) {
      this.error = 'Fill required fields.';
      return;
    }
    const v = this.form.getRawValue();
    if (!v.email && !v.phone) {
      this.error = 'Provide email or phone.';
      return;
    }

    this.loading = true;
    this.auth.register(v).subscribe({
      next: () => {
        this.loading = false;
        this.router.navigateByUrl('/login');
      },
      error: (e) => {
        this.loading = false;
        this.error = e?.error?.message || e?.error?.detail || 'Registration failed.';
      },
    });
  }
}

