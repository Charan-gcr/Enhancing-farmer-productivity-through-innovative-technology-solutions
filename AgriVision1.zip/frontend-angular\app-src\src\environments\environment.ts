export const environment = {
  production: false,
  authBaseUrl: 'http://localhost:8081',
  cropBaseUrl: 'http://localhost:8082',
  adminBaseUrl: 'http://localhost:8083',
};

