import { Component } from '@angular/core';
import { AdminService, AnalysisRow, LoginRow, Stats, UserRow } from '../../core/admin/admin.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
})
export class AdminComponent {
  loading = false;
  error = '';

  stats: Stats | null = null;
  users: UserRow[] = [];
  logins: LoginRow[] = [];
  analyses: AnalysisRow[] = [];

  constructor(private admin: AdminService) {}

  ngOnInit() {
    this.refresh();
  }

  refresh() {
    this.loading = true;
    this.error = '';

    this.admin.stats().subscribe({
      next: (s) => (this.stats = s),
      error: (e) => (this.error = e?.error?.detail || 'Failed to load stats.'),
    });
    this.admin.users().subscribe({ next: (r) => (this.users = r) });
    this.admin.logins().subscribe({ next: (r) => (this.logins = r) });
    this.admin.analyses().subscribe({
      next: (r) => (this.analyses = r),
      error: () => {},
      complete: () => (this.loading = false),
    });
  }
}

