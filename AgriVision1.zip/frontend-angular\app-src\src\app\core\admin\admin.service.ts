import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

export type Stats = { totalUsers: number; totalLogins: number; totalAnalyses: number };
export type UserRow = { id: number; fullName: string; email: string | null; phone: string | null; role: string; createdAt: string };
export type LoginRow = { id: number; userId: number; username: string; outcome: string; ipAddress: string; createdAt: string };
export type AnalysisRow = { id: number; userId: number; crop: string; symptom: string; location: string; createdAt: string };

@Injectable({ providedIn: 'root' })
export class AdminService {
  constructor(private http: HttpClient) {}

  stats() {
    return this.http.get<Stats>(`${environment.adminBaseUrl}/admin/stats`);
  }

  users(page = 0, size = 25) {
    return this.http.get<UserRow[]>(`${environment.adminBaseUrl}/admin/users?page=${page}&size=${size}`);
  }

  logins(page = 0, size = 25) {
    return this.http.get<LoginRow[]>(`${environment.adminBaseUrl}/admin/logins?page=${page}&size=${size}`);
  }

  analyses(page = 0, size = 25) {
    return this.http.get<AnalysisRow[]>(`${environment.adminBaseUrl}/admin/analyses?page=${page}&size=${size}`);
  }
}

