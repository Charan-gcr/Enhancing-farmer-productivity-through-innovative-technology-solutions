package com.agrivision.auth.user;

public enum UserRole {
    USER,
    ADMIN
}

