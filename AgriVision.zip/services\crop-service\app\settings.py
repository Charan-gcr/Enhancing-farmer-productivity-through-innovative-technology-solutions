from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="CROP_", extra="ignore")

    JWT_SECRET: str
    JWT_ISSUER: str = "agri-auth"
    JWT_AUDIENCE: str = "agri-frontend"
    CORS_ORIGINS: str = "http://localhost:4200"

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]


settings = Settings()

