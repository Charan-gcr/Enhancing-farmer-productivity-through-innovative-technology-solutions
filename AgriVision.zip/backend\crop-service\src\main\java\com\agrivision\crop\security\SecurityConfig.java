package com.agrivision.crop.security;

import com.agrivision.shared.security.JwtAuthFilter;
import com.agrivision.shared.security.JwtService;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Bean
    @ConfigurationProperties(prefix = "agri.jwt")
    public JwtProps jwtProps() {
        return new JwtProps();
    }

    @Bean
    public JwtService jwtService(JwtProps props) {
        return new JwtService(props.getIssuer(), props.getAudience(), props.getSecret());
    }

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http, JwtService jwtService) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .cors(Customizer.withDefaults())
                .addFilterBefore(new JwtAuthFilter(jwtService), UsernamePasswordAuthenticationFilter.class)
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/actuator/health", "/actuator/info").permitAll()
                        .requestMatchers(HttpMethod.POST, "/crop/analyze").authenticated()
                        .anyRequest().denyAll()
                );
        return http.build();
    }
}

