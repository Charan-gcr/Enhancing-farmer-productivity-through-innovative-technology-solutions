-- Create database and user (adjust passwords as needed)
CREATE DATABASE IF NOT EXISTS agri CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- If you want: create user (run as root)
-- CREATE USER IF NOT EXISTS 'agri'@'%' IDENTIFIED BY 'agri_password';
-- GRANT ALL PRIVILEGES ON agri.* TO 'agri'@'%';
-- FLUSH PRIVILEGES;

USE agri;

-- Tables are auto-created by JPA (ddl-auto=update) when you run services.
-- This file exists mainly to bootstrap the DB/schema and document expected tables:
-- users, login_audit, analysis_audit

