package com.agrivision.auth.auth.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class AuthDtos {
    public record RegisterRequest(
            @NotBlank @Size(min = 2, max = 200) String fullName,
            @Email @Size(max = 320) String email,
            @Pattern(regexp = "^[0-9+][0-9]{6,31}$", message = "Invalid phone") String phone,
            @NotBlank @Size(min = 8, max = 200) String password
    ) {}

    public record LoginRequest(
            @NotBlank @Size(min = 3, max = 320) String username,
            @NotBlank @Size(min = 1, max = 200) String password
    ) {}

    public record TokenResponse(String accessToken, String tokenType) {}

    public record UserResponse(Long id, String fullName, String email, String phone, String role) {}
}

