from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="AUTH_", extra="ignore")

    # Default to SQLite so the service can run without MySQL locally.
    # In production, set AUTH_DATABASE_URL to a MySQL connection string.
    DATABASE_URL: str = "sqlite:///./agri.db"
    JWT_ISSUER: str = "agri-auth"
    JWT_AUDIENCE: str = "agri-frontend"
    JWT_SECRET: str
    ACCESS_TOKEN_MINUTES: int = 60
    CORS_ORIGINS: str = "http://localhost:4200"

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]


settings = Settings()

