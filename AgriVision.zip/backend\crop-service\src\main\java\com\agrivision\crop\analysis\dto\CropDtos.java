package com.agrivision.crop.analysis.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class CropDtos {
    public record AnalyzeCropRequest(
            @NotBlank @Size(max = 60) String crop,
            @NotBlank @Size(max = 40) String symptom,
            @NotBlank @Size(min = 2, max = 200) String location
    ) {}

    public record AnalyzeCropResponse(
            String soilSummary,
            String yieldSummary,
            String diseaseStatus,
            String treatmentSummary
    ) {}
}

