$ErrorActionPreference = "Stop"

Write-Host "Starting Agri backend services..." -ForegroundColor Cyan
Write-Host "Prereqs: Java 17+, MySQL running, DB 'agri' exists." -ForegroundColor Yellow

Push-Location "$PSScriptRoot\backend"

Write-Host "Building backend..." -ForegroundColor Cyan
mvn -q -DskipTests clean package

Write-Host "Run each service in a separate terminal:" -ForegroundColor Green
Write-Host "  cd backend/auth-service  ; mvn spring-boot:run" -ForegroundColor Green
Write-Host "  cd backend/crop-service  ; mvn spring-boot:run" -ForegroundColor Green
Write-Host "  cd backend/admin-service ; mvn spring-boot:run" -ForegroundColor Green

Pop-Location

