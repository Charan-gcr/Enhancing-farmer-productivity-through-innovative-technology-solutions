from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .db import Base, engine, get_db
from .models import User
from .schemas import LoginRequest, RegisterRequest, TokenResponse, UserResponse
from .security import create_access_token, hash_password, verify_password
from .settings import settings


app = FastAPI(title="Agri Auth Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def _startup():
    Base.metadata.create_all(bind=engine)


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/auth/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    if payload.email is None and payload.phone is None:
        raise HTTPException(status_code=400, detail="Provide email or phone.")

    user = User(
        full_name=payload.full_name.strip(),
        email=str(payload.email).lower().strip() if payload.email else None,
        phone=payload.phone.strip() if payload.phone else None,
        password_hash=hash_password(payload.password),
    )

    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="User already exists with that email/phone.")

    db.refresh(user)
    return UserResponse(id=user.id, full_name=user.full_name, email=user.email, phone=user.phone)


@app.post("/auth/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    uname = payload.username.strip()
    stmt = select(User).where(or_(User.email == uname.lower(), User.phone == uname))
    user = db.execute(stmt).scalars().first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials.")

    token = create_access_token(subject=str(user.id))
    return TokenResponse(access_token=token)

