package com.agrivision.admin.monitor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoginAuditRepository extends JpaRepository<LoginAuditEntity, Long> {
    Page<LoginAuditEntity> findAllByOrderByCreatedAtDesc(Pageable pageable);
}

