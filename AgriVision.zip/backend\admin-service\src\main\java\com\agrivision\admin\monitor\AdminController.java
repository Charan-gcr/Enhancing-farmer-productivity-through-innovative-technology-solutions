package com.agrivision.admin.monitor;

import com.agrivision.admin.monitor.dto.AdminDtos;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {
    private final UserRepository users;
    private final LoginAuditRepository logins;
    private final AnalysisAuditRepository analyses;

    public AdminController(UserRepository users, LoginAuditRepository logins, AnalysisAuditRepository analyses) {
        this.users = users;
        this.logins = logins;
        this.analyses = analyses;
    }

    @GetMapping("/stats")
    public AdminDtos.Stats stats() {
        return new AdminDtos.Stats(users.count(), logins.count(), analyses.count());
    }

    @GetMapping("/users")
    public List<AdminDtos.UserRow> listUsers(@RequestParam(defaultValue = "0") int page,
                                             @RequestParam(defaultValue = "25") int size) {
        return users.findAllByOrderByCreatedAtDesc(PageRequest.of(page, Math.min(size, 200)))
                .map(u -> new AdminDtos.UserRow(u.getId(), u.getFullName(), u.getEmail(), u.getPhone(), u.getRole(), u.getCreatedAt()))
                .toList();
    }

    @GetMapping("/logins")
    public List<AdminDtos.LoginRow> listLogins(@RequestParam(defaultValue = "0") int page,
                                               @RequestParam(defaultValue = "25") int size) {
        return logins.findAllByOrderByCreatedAtDesc(PageRequest.of(page, Math.min(size, 200)))
                .map(l -> new AdminDtos.LoginRow(l.getId(), l.getUserId(), l.getUsername(), l.getOutcome(), l.getIpAddress(), l.getCreatedAt()))
                .toList();
    }

    @GetMapping("/analyses")
    public List<AdminDtos.AnalysisRow> listAnalyses(@RequestParam(defaultValue = "0") int page,
                                                    @RequestParam(defaultValue = "25") int size) {
        return analyses.findAllByOrderByCreatedAtDesc(PageRequest.of(page, Math.min(size, 200)))
                .map(a -> new AdminDtos.AnalysisRow(a.getId(), a.getUserId(), a.getCrop(), a.getSymptom(), a.getLocation(), a.getCreatedAt()))
                .toList();
    }
}

