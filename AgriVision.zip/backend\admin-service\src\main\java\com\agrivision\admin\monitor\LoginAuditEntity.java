package com.agrivision.admin.monitor;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "login_audit", indexes = {
        @Index(name = "idx_login_user", columnList = "userId"),
        @Index(name = "idx_login_created", columnList = "createdAt")
})
public class LoginAuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long userId;

    @Column(nullable = false, length = 60)
    private String username;

    @Column(nullable = false, length = 30)
    private String outcome; // SUCCESS / FAIL

    @Column(nullable = false, length = 45)
    private String ipAddress;

    @Column(nullable = false)
    private Instant createdAt;

    public Long getId() { return id; }
    public Long getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getOutcome() { return outcome; }
    public String getIpAddress() { return ipAddress; }
    public Instant getCreatedAt() { return createdAt; }
}

