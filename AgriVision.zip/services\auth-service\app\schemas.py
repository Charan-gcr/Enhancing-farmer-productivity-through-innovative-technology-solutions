from pydantic import BaseModel, Field


class RegisterRequest(BaseModel):
    full_name: str = Field(min_length=2, max_length=200)
    # Keep email as a plain string to avoid requiring `email-validator`.
    # (We still do basic presence / format validation.)
    email: str | None = Field(default=None, pattern=r"^.+@.+\..+$", max_length=320)
    phone: str | None = Field(default=None, min_length=7, max_length=32)
    password: str = Field(min_length=8, max_length=200)


class LoginRequest(BaseModel):
    username: str = Field(min_length=3, max_length=320)  # email or phone
    password: str = Field(min_length=1, max_length=200)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "Bearer"


class UserResponse(BaseModel):
    id: int
    full_name: str
    email: str | None
    phone: str | None

