package com.agrivision.crop.analysis;

import com.agrivision.crop.analysis.dto.CropDtos;
import com.agrivision.shared.security.SecurityUtil;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/crop")
public class CropController {
    private final AnalysisAuditRepository audits;

    public CropController(AnalysisAuditRepository audits) {
        this.audits = audits;
    }

    @PostMapping("/analyze")
    public CropDtos.AnalyzeCropResponse analyze(@Valid @RequestBody CropDtos.AnalyzeCropRequest req) {
        String userIdStr = SecurityUtil.requireUserId();
        long userId = Long.parseLong(userIdStr);

        AnalysisAuditEntity a = new AnalysisAuditEntity();
        a.setUserId(userId);
        a.setCrop(req.crop().trim());
        a.setSymptom(req.symptom() == null || req.symptom().isBlank() ? "none" : req.symptom().trim());
        a.setLocation(req.location().trim());
        audits.save(a);

        String soil = "For " + a.getCrop() + " in " + a.getLocation() + ": recommend well-drained loam and periodic soil testing.";
        String yield = "Yield tips: choose correct sowing window, balanced NPK, and proper irrigation scheduling.";

        String disease;
        String treatment;
        if ("none".equalsIgnoreCase(a.getSymptom()) || "healthy".equalsIgnoreCase(a.getSymptom())) {
            disease = "Healthy (no disease symptoms reported).";
            treatment = "Continue good agricultural practices and monitor plants regularly.";
        } else {
            disease = "Potential issue detected: " + a.getSymptom() + ".";
            treatment = "Suggested actions: remove affected leaves, improve airflow, and follow integrated pest management.";
        }

        return new CropDtos.AnalyzeCropResponse(soil, yield, disease, treatment);
    }
}

