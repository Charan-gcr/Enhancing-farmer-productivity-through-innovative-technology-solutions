package com.agrivision.auth.auth;

import com.agrivision.auth.auth.dto.AuthDtos;
import com.agrivision.auth.audit.LoginAuditEntity;
import com.agrivision.auth.audit.LoginAuditRepository;
import com.agrivision.auth.security.JwtProps;
import com.agrivision.auth.security.PasswordService;
import com.agrivision.auth.user.UserEntity;
import com.agrivision.auth.user.UserRepository;
import com.agrivision.auth.user.UserRole;
import com.agrivision.shared.security.JwtService;
import jakarta.validation.Valid;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/auth")
public class AuthController {
    private final UserRepository users;
    private final PasswordService passwordService;
    private final JwtService jwtService;
    private final JwtProps jwtProps;
    private final LoginAuditRepository loginAudits;

    public AuthController(UserRepository users, PasswordService passwordService, JwtService jwtService, JwtProps jwtProps, LoginAuditRepository loginAudits) {
        this.users = users;
        this.passwordService = passwordService;
        this.jwtService = jwtService;
        this.jwtProps = jwtProps;
        this.loginAudits = loginAudits;
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public AuthDtos.UserResponse register(@Valid @RequestBody AuthDtos.RegisterRequest req) {
        if ((req.email() == null || req.email().isBlank()) && (req.phone() == null || req.phone().isBlank())) {
            throw new BadRequestException("Provide email or phone.");
        }

        UserEntity u = new UserEntity();
        u.setFullName(req.fullName().trim());
        u.setEmail(req.email() != null && !req.email().isBlank() ? req.email().trim().toLowerCase() : null);
        u.setPhone(req.phone() != null && !req.phone().isBlank() ? req.phone().trim() : null);
        u.setPasswordHash(passwordService.hash(req.password()));
        u.setRole(UserRole.USER);

        try {
            u = users.save(u);
        } catch (DataIntegrityViolationException e) {
            throw new ConflictException("User already exists with that email/phone.");
        }

        return new AuthDtos.UserResponse(u.getId(), u.getFullName(), u.getEmail(), u.getPhone(), u.getRole().name());
    }

    @PostMapping("/login")
    public AuthDtos.TokenResponse login(@Valid @RequestBody AuthDtos.LoginRequest req, HttpServletRequest httpReq) {
        String uname = req.username().trim();
        Optional<UserEntity> userOpt = uname.contains("@")
                ? users.findByEmailIgnoreCase(uname)
                : users.findByPhone(uname);

        UserEntity u = userOpt.orElse(null);
        boolean ok = u != null && passwordService.matches(req.password(), u.getPasswordHash());

        LoginAuditEntity audit = new LoginAuditEntity();
        audit.setUserId(u != null ? u.getId() : 0L);
        audit.setUsername(uname);
        audit.setOutcome(ok ? "SUCCESS" : "FAIL");
        audit.setIpAddress(extractIp(httpReq));
        loginAudits.save(audit);

        if (!ok) throw new UnauthorizedException("Invalid credentials.");

        String token = jwtService.createToken(
                String.valueOf(u.getId()),
                List.of(u.getRole().name()),
                jwtProps.getAccessTokenTtlSeconds()
        );

        return new AuthDtos.TokenResponse(token, "Bearer");
    }

    private static String extractIp(HttpServletRequest req) {
        String fwd = req.getHeader("X-Forwarded-For");
        if (fwd != null && !fwd.isBlank()) return fwd.split(",")[0].trim();
        return req.getRemoteAddr() != null ? req.getRemoteAddr() : "unknown";
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    private static class BadRequestException extends RuntimeException {
        public BadRequestException(String message) { super(message); }
    }

    @ResponseStatus(HttpStatus.CONFLICT)
    private static class ConflictException extends RuntimeException {
        public ConflictException(String message) { super(message); }
    }

    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    private static class UnauthorizedException extends RuntimeException {
        public UnauthorizedException(String message) { super(message); }
    }
}

