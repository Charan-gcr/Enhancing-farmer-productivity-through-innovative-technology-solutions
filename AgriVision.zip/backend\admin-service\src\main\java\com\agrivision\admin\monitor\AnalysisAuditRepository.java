package com.agrivision.admin.monitor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnalysisAuditRepository extends JpaRepository<AnalysisAuditEntity, Long> {
    Page<AnalysisAuditEntity> findAllByOrderByCreatedAtDesc(Pageable pageable);
}

