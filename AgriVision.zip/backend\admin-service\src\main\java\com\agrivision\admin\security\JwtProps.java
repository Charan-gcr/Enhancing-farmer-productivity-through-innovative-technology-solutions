package com.agrivision.admin.security;

public class JwtProps {
    private String issuer;
    private String audience;
    private String secret;

    public String getIssuer() { return issuer; }
    public void setIssuer(String issuer) { this.issuer = issuer; }
    public String getAudience() { return audience; }
    public void setAudience(String audience) { this.audience = audience; }
    public String getSecret() { return secret; }
    public void setSecret(String secret) { this.secret = secret; }
}

