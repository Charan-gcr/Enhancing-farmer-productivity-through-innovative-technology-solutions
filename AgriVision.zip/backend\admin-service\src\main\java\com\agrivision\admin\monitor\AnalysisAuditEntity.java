package com.agrivision.admin.monitor;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "analysis_audit", indexes = {
        @Index(name = "idx_analysis_user", columnList = "userId"),
        @Index(name = "idx_analysis_created", columnList = "createdAt")
})
public class AnalysisAuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long userId;

    @Column(nullable = false, length = 60)
    private String crop;

    @Column(nullable = false, length = 40)
    private String symptom;

    @Column(nullable = false, length = 200)
    private String location;

    @Column(nullable = false)
    private Instant createdAt;

    public Long getId() { return id; }
    public Long getUserId() { return userId; }
    public String getCrop() { return crop; }
    public String getSymptom() { return symptom; }
    public String getLocation() { return location; }
    public Instant getCreatedAt() { return createdAt; }
}

