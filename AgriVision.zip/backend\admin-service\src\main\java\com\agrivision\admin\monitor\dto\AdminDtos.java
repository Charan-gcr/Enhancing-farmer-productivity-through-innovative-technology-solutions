package com.agrivision.admin.monitor.dto;

import java.time.Instant;

public class AdminDtos {
    public record UserRow(Long id, String fullName, String email, String phone, String role, Instant createdAt) {}
    public record LoginRow(Long id, Long userId, String username, String outcome, String ipAddress, Instant createdAt) {}
    public record AnalysisRow(Long id, Long userId, String crop, String symptom, String location, Instant createdAt) {}
    public record Stats(long totalUsers, long totalLogins, long totalAnalyses) {}
}

