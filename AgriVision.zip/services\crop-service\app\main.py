from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .security import require_user_id
from .schemas import AnalyzeCropRequest, AnalyzeCropResponse
from .settings import settings

app = FastAPI(title="Agri Crop Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def _startup():
    # No DB in this service yet; placeholder for future persistence.
    pass


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/crop/analyze", response_model=AnalyzeCropResponse)
def analyze_crop(
    payload: AnalyzeCropRequest,
    user_id: str = Depends(require_user_id),
):
    # Placeholder intelligence — replace with real model logic later.
    crop = payload.crop.strip()
    symptom = payload.symptom.strip()
    location = payload.location.strip()

    soil_summary = f"For {crop} in {location}: recommend well-drained loam and regular soil testing."
    yield_summary = f"Yield tips for {crop} ({location}): optimize sowing time, irrigation scheduling, and nutrient balance."

    if symptom == "none":
        disease_status = "Healthy (no disease symptoms reported)."
        treatment_summary = "Continue good agricultural practices and monitor plants regularly."
    else:
        disease_status = f"Potential issue detected: {symptom.replace('_', ' ')}."
        treatment_summary = f"Suggested prevention: remove affected leaves, improve airflow, and use location-appropriate integrated pest management."

    # user_id is currently unused, but required to validate auth.
    _ = user_id

    return AnalyzeCropResponse(
        soil_summary=soil_summary,
        yield_summary=yield_summary,
        disease_status=disease_status,
        treatment_summary=treatment_summary,
    )

