package com.agrivision.auth.security;

import com.agrivision.shared.security.JwtService;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JwtConfig {
    @Bean
    @ConfigurationProperties(prefix = "agri.jwt")
    public JwtProps jwtProps() {
        return new JwtProps();
    }

    @Bean
    public JwtService jwtService(JwtProps props) {
        return new JwtService(props.getIssuer(), props.getAudience(), props.getSecret());
    }
}

