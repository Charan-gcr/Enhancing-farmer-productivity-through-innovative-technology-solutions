package com.agrivision.shared.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class JwtAuthFilter extends OncePerRequestFilter {
    private final JwtService jwtService;

    public JwtAuthFilter(JwtService jwtService) {
        this.jwtService = jwtService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        String header = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (header == null || !header.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        String token = header.substring("Bearer ".length()).trim();
        try {
            Jws<Claims> parsed = jwtService.parse(token);
            Claims claims = parsed.getPayload();

            String userId = claims.getSubject();
            if (userId == null || userId.isBlank()) {
                filterChain.doFilter(request, response);
                return;
            }

            Object rolesObj = claims.get("roles");
            List<SimpleGrantedAuthority> authorities = new ArrayList<>();
            if (rolesObj instanceof List<?> roles) {
                for (Object r : roles) {
                    if (r == null) continue;
                    String role = Objects.toString(r, "").trim();
                    if (!role.isEmpty()) {
                        // Spring expects ROLE_ prefix for hasRole checks.
                        authorities.add(new SimpleGrantedAuthority("ROLE_" + role));
                    }
                }
            }

            SecurityContextHolder.getContext().setAuthentication(new JwtAuthentication(userId, token, authorities));
        } catch (Exception ignored) {
            // Invalid token -> treat as unauthenticated, downstream will 401 if required.
        }

        filterChain.doFilter(request, response);
    }
}

