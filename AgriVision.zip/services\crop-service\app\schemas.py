from pydantic import BaseModel, Field


class AnalyzeCropRequest(BaseModel):
    crop: str = Field(min_length=1, max_length=60)
    symptom: str = Field(default="none", max_length=40)
    location: str = Field(min_length=2, max_length=200)


class AnalyzeCropResponse(BaseModel):
    soil_summary: str
    yield_summary: str
    disease_status: str
    treatment_summary: str

