## Agri Vision India (Angular + Java Microservices + MySQL)

This repo contains:

- **Frontend (Angular)**: planned under `frontend-angular/` (see note below)
- **Backend (Java Spring Boot microservices)**: under `backend/`
  - `auth-service` (port **8081**): register/login, BCrypt password hashing, JWT, roles
  - `crop-service` (port **8082**): JWT-protected `/crop/analyze` requiring **location**
  - `admin-service` (port **8083**): JWT-protected `/admin/*` (ADMIN only) monitoring APIs
- **MySQL bootstrap**: `infra/mysql/schema.sql`

### Prerequisites (later, when you run)

- Java 17+
- Maven
- MySQL 8+
- Node.js LTS + Angular CLI (for frontend)

### MySQL setup

Create database `agri` (and optional user):

- Run `infra/mysql/schema.sql` in MySQL.
- Update credentials in:
  - `backend/auth-service/src/main/resources/application.yml`
  - `backend/crop-service/src/main/resources/application.yml`
  - `backend/admin-service/src/main/resources/application.yml`

### Run backend (VS Code Terminal)

From `backend/`:

```bash
mvn -q -DskipTests clean package
```

Then run each service (in separate terminals):

```bash
cd backend/auth-service && mvn spring-boot:run
cd backend/crop-service && mvn spring-boot:run
cd backend/admin-service && mvn spring-boot:run
```

### API quick overview

- **Auth**
  - `POST /auth/register`
  - `POST /auth/login` → returns JWT `accessToken`
- **Crop (requires Authorization header)**
  - `POST /crop/analyze` body includes `crop`, `symptom`, **`location`**
- **Admin (requires ADMIN role)**
  - `GET /admin/stats`
  - `GET /admin/users?page=0&size=25`
  - `GET /admin/logins?page=0&size=25`
  - `GET /admin/analyses?page=0&size=25`

### Angular note

Angular scaffolding is normally created via `ng new ...`. Since this machine currently doesn’t have Node/npm installed, I didn’t generate a full Angular CLI project yet.

When you’re ready, install Node + Angular CLI, then I’ll add the full Angular app (login/register + location selection + admin dashboard UI) into `frontend-angular/` and wire it to these backend APIs.

